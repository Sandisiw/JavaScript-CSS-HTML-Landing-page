function favourite_games()
{
    
    let games = prompt("What are your Favourite Games (Action, Platform, Shooter, Fighting, Stealth)?");

    if(games !="")
    {
        alert("Excellent Choice, most gamers also like: \n"+games);
    }
    else
    {
        alert('Not sure yet?\nFind more about video game genres \nhttps://en.wikipedia.org/wiki/List_of_video_game_genres');
    }
}

